﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {
        char op,eq;                            //for storing operators,eq.
        double v1,v2,r,m;                           //for storing operands,results & memory.

        public Form1()
        {
            InitializeComponent();
        }

        private void SetButton(string b)
        {
            if (eq == '=')
                Null();

            if (op == '\0')
            {
                if (label1.Text == "0")
                    label1.Text = null;

                label1.Text += b;
            }
            else
            {
                if (label2.Text == "0")
                    label2.Text = null;

                label2.Text += b;
            }
        }
        private void Null()
        {
            MonitorLebel.Text = null;
            label1.Text = null;
            label2.Text = null;
            OpL.Text = null;
            eq='\0';
            op='\0';
        }

        private void AC_Click(object sender, EventArgs e)
        {
            Null();
        }

        private void button0_Click(object sender, EventArgs e)
        {
            if (eq == '=')
                Null();

            if (op == '\0')
            {
                if (label1.Text == "0") { }
                else
                    label1.Text += "0";
            }
            else
            {
                if (label2.Text == "0") { }
                else
                    label2.Text += "0";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SetButton("1");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SetButton("2");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SetButton("3");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SetButton("4");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SetButton("5");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            SetButton("6");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            SetButton("7");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            SetButton("8");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            SetButton("9");
        }

        private void Dot_Click(object sender, EventArgs e)
        {
            SetButton(".");
        }

        private void Add_Click(object sender, EventArgs e)
        {
            op = '+';
            OpL.Text = "+";
            v1 = Convert.ToDouble(label1.Text);
        }

        private void Min_Click(object sender, EventArgs e)
        {
            op = '-';
            OpL.Text = "-";
            v1 = Convert.ToDouble(label1.Text);
        }

        private void Mul_Click(object sender, EventArgs e)
        {
            op = '*';
            OpL.Text = "X";
            v1 = Convert.ToDouble(label1.Text);
        }

        private void Div_Click(object sender, EventArgs e)
        {
            op = '/';
            OpL.Text = "÷";
            v1 = Convert.ToDouble(label1.Text);
        }

        private void Equal_Click(object sender, EventArgs e)
        {
            eq='=';
            v2 = Convert.ToDouble(label2.Text);
            switch (op)
            {
                case '+':
                    r = v1 + v2;
                    break;

                case '-':
                    r = v1 - v2;
                    break;

                case '*':
                    r = v1 * v2;
                    break;

                case '/':
                    if (label2.Text == "0")
                        MonitorLebel.Text = "Can't Divide By Zero!";
                    else
                        r = v1 / v2;
                    break;

                default:
                    MonitorLebel.Text=label1.Text;
                    break;
            }

            if (MonitorLebel.Text == "Can't Divide By Zero!") { }
            else
            {
                if (op == '\0') { }
                else
                    MonitorLebel.Text = Convert.ToString(r);
            }
        }

        private void C_Click(object sender, EventArgs e)
        {
            if (label2.Text == null && MonitorLebel.Text == null)
                label1.Text = null;
            else if (label1.Text==null && MonitorLebel.Text == null)
                label2.Text = null;
            else
                MonitorLebel.Text = null;

        }

        private void MPlus_Click(object sender, EventArgs e)
        {
            label3.Text = "M+";

            if (label2.Text == null && MonitorLebel.Text == null)
                m +=Convert.ToDouble(label1.Text);
            else if (label1.Text == null && MonitorLebel.Text == null)
                m += Convert.ToDouble(label2.Text);
            else
                m += Convert.ToDouble(MonitorLebel.Text);

        }

        private void MMin_Click(object sender, EventArgs e)
        {
            label3.Text = "M-";

            if (label2.Text == null && MonitorLebel.Text == null)
                m -= Convert.ToDouble(label1.Text);
            else if (label1.Text == null && MonitorLebel.Text == null)
                m -= Convert.ToDouble(label2.Text);
            else
                m -= Convert.ToDouble(MonitorLebel.Text);
        }

        private void M_Click(object sender, EventArgs e)
        {
            MonitorLebel.Text = Convert.ToString(m);
            m = 0;
            label3.Text = null;
        }

        private void Percentage_Click(object sender, EventArgs e)
        {
            r *= 0.01;
            MonitorLebel.Text = Convert.ToString(r);
        }

        private void Root_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("Comming Soon");
            double p;
            OpL.Text = "√";

            if (label2.Text == null && MonitorLebel.Text == null)
                p = Convert.ToDouble(label1.Text);
            else if (label1.Text == null && MonitorLebel.Text == null)
                p= Convert.ToDouble(label2.Text);
            else
                p= Convert.ToDouble(MonitorLebel.Text);

            label1.Text = null;
            label2.Text = Convert.ToString(p);
            p = Math.Pow(p, 0.5);
            MonitorLebel.Text = Convert.ToString(p);

        }
    }
}
