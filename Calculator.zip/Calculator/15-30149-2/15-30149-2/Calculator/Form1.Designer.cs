﻿namespace Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.AC = new System.Windows.Forms.Button();
            this.C = new System.Windows.Forms.Button();
            this.MPlus = new System.Windows.Forms.Button();
            this.MMin = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.M = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.Dot = new System.Windows.Forms.Button();
            this.button0 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.Percentage = new System.Windows.Forms.Button();
            this.Root = new System.Windows.Forms.Button();
            this.Mul = new System.Windows.Forms.Button();
            this.Add = new System.Windows.Forms.Button();
            this.Div = new System.Windows.Forms.Button();
            this.Min = new System.Windows.Forms.Button();
            this.Equal = new System.Windows.Forms.Button();
            this.MonitorLebel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.OpL = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // AC
            // 
            this.AC.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AC.ForeColor = System.Drawing.SystemColors.InfoText;
            this.AC.Location = new System.Drawing.Point(12, 348);
            this.AC.Name = "AC";
            this.AC.Size = new System.Drawing.Size(54, 56);
            this.AC.TabIndex = 1;
            this.AC.Text = "AC";
            this.AC.UseVisualStyleBackColor = true;
            this.AC.Click += new System.EventHandler(this.AC_Click);
            // 
            // C
            // 
            this.C.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C.ForeColor = System.Drawing.SystemColors.ControlText;
            this.C.Location = new System.Drawing.Point(12, 286);
            this.C.Name = "C";
            this.C.Size = new System.Drawing.Size(54, 56);
            this.C.TabIndex = 2;
            this.C.Text = "C";
            this.C.UseVisualStyleBackColor = true;
            this.C.Click += new System.EventHandler(this.C_Click);
            // 
            // MPlus
            // 
            this.MPlus.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MPlus.ForeColor = System.Drawing.SystemColors.ControlText;
            this.MPlus.Location = new System.Drawing.Point(12, 224);
            this.MPlus.Name = "MPlus";
            this.MPlus.Size = new System.Drawing.Size(54, 56);
            this.MPlus.TabIndex = 3;
            this.MPlus.Text = "M+";
            this.MPlus.UseVisualStyleBackColor = true;
            this.MPlus.Click += new System.EventHandler(this.button2_Click);
            // 
            // MMin
            // 
            this.MMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MMin.ForeColor = System.Drawing.SystemColors.ControlText;
            this.MMin.Location = new System.Drawing.Point(12, 162);
            this.MMin.Name = "MMin";
            this.MMin.Size = new System.Drawing.Size(54, 56);
            this.MMin.TabIndex = 4;
            this.MMin.Text = "M-";
            this.MMin.UseVisualStyleBackColor = true;
            this.MMin.Click += new System.EventHandler(this.MPlus_Click);
            // 
            // button8
            // 
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button8.Location = new System.Drawing.Point(132, 162);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(54, 56);
            this.button8.TabIndex = 5;
            this.button8.Text = "8";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // M
            // 
            this.M.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M.ForeColor = System.Drawing.SystemColors.ControlText;
            this.M.Location = new System.Drawing.Point(72, 348);
            this.M.Name = "M";
            this.M.Size = new System.Drawing.Size(54, 56);
            this.M.TabIndex = 6;
            this.M.Text = "M";
            this.M.UseVisualStyleBackColor = true;
            this.M.Click += new System.EventHandler(this.M_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button1.Location = new System.Drawing.Point(72, 286);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(54, 56);
            this.button1.TabIndex = 7;
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button4.Location = new System.Drawing.Point(72, 224);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(54, 56);
            this.button4.TabIndex = 8;
            this.button4.Text = "4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button7.Location = new System.Drawing.Point(72, 162);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(54, 56);
            this.button7.TabIndex = 9;
            this.button7.Text = "7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // Dot
            // 
            this.Dot.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dot.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Dot.Location = new System.Drawing.Point(192, 348);
            this.Dot.Name = "Dot";
            this.Dot.Size = new System.Drawing.Size(54, 56);
            this.Dot.TabIndex = 10;
            this.Dot.Text = ".";
            this.Dot.UseVisualStyleBackColor = true;
            this.Dot.Click += new System.EventHandler(this.Dot_Click);
            // 
            // button0
            // 
            this.button0.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button0.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button0.Location = new System.Drawing.Point(132, 347);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(54, 56);
            this.button0.TabIndex = 11;
            this.button0.Text = "0";
            this.button0.UseVisualStyleBackColor = true;
            this.button0.Click += new System.EventHandler(this.button0_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button2.Location = new System.Drawing.Point(132, 286);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(54, 56);
            this.button2.TabIndex = 12;
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button5.Location = new System.Drawing.Point(132, 224);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(54, 56);
            this.button5.TabIndex = 13;
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button9.Location = new System.Drawing.Point(192, 162);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(54, 56);
            this.button9.TabIndex = 14;
            this.button9.Text = "9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button3.Location = new System.Drawing.Point(195, 286);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(54, 56);
            this.button3.TabIndex = 15;
            this.button3.Text = "3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button6.Location = new System.Drawing.Point(192, 224);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(54, 56);
            this.button6.TabIndex = 16;
            this.button6.Text = "6";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // Percentage
            // 
            this.Percentage.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Percentage.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Percentage.Location = new System.Drawing.Point(252, 162);
            this.Percentage.Name = "Percentage";
            this.Percentage.Size = new System.Drawing.Size(54, 56);
            this.Percentage.TabIndex = 17;
            this.Percentage.Text = "%";
            this.Percentage.UseVisualStyleBackColor = true;
            this.Percentage.Click += new System.EventHandler(this.Percentage_Click);
            // 
            // Root
            // 
            this.Root.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Root.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Root.Location = new System.Drawing.Point(312, 162);
            this.Root.Name = "Root";
            this.Root.Size = new System.Drawing.Size(54, 56);
            this.Root.TabIndex = 18;
            this.Root.Text = "√";
            this.Root.UseVisualStyleBackColor = true;
            this.Root.Click += new System.EventHandler(this.Root_Click);
            // 
            // Mul
            // 
            this.Mul.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mul.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Mul.Location = new System.Drawing.Point(252, 224);
            this.Mul.Name = "Mul";
            this.Mul.Size = new System.Drawing.Size(54, 56);
            this.Mul.TabIndex = 19;
            this.Mul.Text = "X";
            this.Mul.UseVisualStyleBackColor = true;
            this.Mul.Click += new System.EventHandler(this.Mul_Click);
            // 
            // Add
            // 
            this.Add.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Add.Location = new System.Drawing.Point(252, 286);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(54, 117);
            this.Add.TabIndex = 20;
            this.Add.Text = "+";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // Div
            // 
            this.Div.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Div.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Div.Location = new System.Drawing.Point(312, 224);
            this.Div.Name = "Div";
            this.Div.Size = new System.Drawing.Size(54, 56);
            this.Div.TabIndex = 21;
            this.Div.Text = "÷";
            this.Div.UseVisualStyleBackColor = true;
            this.Div.Click += new System.EventHandler(this.Div_Click);
            // 
            // Min
            // 
            this.Min.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Min.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Min.Location = new System.Drawing.Point(312, 286);
            this.Min.Name = "Min";
            this.Min.Size = new System.Drawing.Size(54, 56);
            this.Min.TabIndex = 22;
            this.Min.Text = "-";
            this.Min.UseVisualStyleBackColor = true;
            this.Min.Click += new System.EventHandler(this.Min_Click);
            // 
            // Equal
            // 
            this.Equal.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Equal.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Equal.Location = new System.Drawing.Point(312, 347);
            this.Equal.Name = "Equal";
            this.Equal.Size = new System.Drawing.Size(54, 56);
            this.Equal.TabIndex = 23;
            this.Equal.Text = "=";
            this.Equal.UseVisualStyleBackColor = true;
            this.Equal.Click += new System.EventHandler(this.Equal_Click);
            // 
            // MonitorLebel
            // 
            this.MonitorLebel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.MonitorLebel.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MonitorLebel.ForeColor = System.Drawing.SystemColors.Desktop;
            this.MonitorLebel.Location = new System.Drawing.Point(12, 25);
            this.MonitorLebel.Name = "MonitorLebel";
            this.MonitorLebel.Size = new System.Drawing.Size(354, 121);
            this.MonitorLebel.TabIndex = 24;
            this.MonitorLebel.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label1.Location = new System.Drawing.Point(64, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(302, 41);
            this.label1.TabIndex = 25;
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label2.Location = new System.Drawing.Point(67, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(299, 40);
            this.label2.TabIndex = 26;
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // OpL
            // 
            this.OpL.BackColor = System.Drawing.Color.White;
            this.OpL.ForeColor = System.Drawing.Color.Navy;
            this.OpL.Location = new System.Drawing.Point(12, 60);
            this.OpL.Name = "OpL";
            this.OpL.Size = new System.Drawing.Size(51, 46);
            this.OpL.TabIndex = 27;
            this.OpL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(12, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 35);
            this.label3.TabIndex = 28;
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(380, 416);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.OpL);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.MonitorLebel);
            this.Controls.Add(this.Equal);
            this.Controls.Add(this.Min);
            this.Controls.Add(this.Div);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.Mul);
            this.Controls.Add(this.Root);
            this.Controls.Add(this.Percentage);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button0);
            this.Controls.Add(this.Dot);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.M);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.MMin);
            this.Controls.Add(this.MPlus);
            this.Controls.Add(this.C);
            this.Controls.Add(this.AC);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "CITIZEN";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button AC;
        private System.Windows.Forms.Button C;
        private System.Windows.Forms.Button MPlus;
        private System.Windows.Forms.Button MMin;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button M;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button Dot;
        private System.Windows.Forms.Button button0;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button Percentage;
        private System.Windows.Forms.Button Root;
        private System.Windows.Forms.Button Mul;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Button Div;
        private System.Windows.Forms.Button Min;
        private System.Windows.Forms.Button Equal;
        private System.Windows.Forms.Label MonitorLebel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label OpL;
        private System.Windows.Forms.Label label3;
    }
}

