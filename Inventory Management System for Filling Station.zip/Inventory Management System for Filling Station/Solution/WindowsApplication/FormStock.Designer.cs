﻿namespace WindowsApplication
{
    partial class FormStock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelStock = new System.Windows.Forms.Label();
            this.buttonG = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.labelDiesel = new System.Windows.Forms.Label();
            this.labelOctane = new System.Windows.Forms.Label();
            this.labelPetrol = new System.Windows.Forms.Label();
            this.labelCNG = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.buttonHome = new System.Windows.Forms.Button();
            this.buttonBackUR_L = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelStock
            // 
            this.labelStock.Font = new System.Drawing.Font("Modern No. 20", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStock.Location = new System.Drawing.Point(348, 9);
            this.labelStock.Name = "labelStock";
            this.labelStock.Size = new System.Drawing.Size(157, 42);
            this.labelStock.TabIndex = 0;
            this.labelStock.Text = "Stock";
            this.labelStock.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // buttonG
            // 
            this.buttonG.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonG.Location = new System.Drawing.Point(612, 17);
            this.buttonG.Name = "buttonG";
            this.buttonG.Size = new System.Drawing.Size(162, 35);
            this.buttonG.TabIndex = 119;
            this.buttonG.Text = "Generate/Refresh";
            this.buttonG.UseVisualStyleBackColor = true;
            this.buttonG.Click += new System.EventHandler(this.buttonG_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(788, 101);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 25);
            this.label10.TabIndex = 123;
            this.label10.Text = "CNG";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(552, 101);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 25);
            this.label9.TabIndex = 122;
            this.label9.Text = "Petrol";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(303, 101);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 25);
            this.label8.TabIndex = 121;
            this.label8.Text = "Octane";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(87, 101);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(78, 25);
            this.label7.TabIndex = 120;
            this.label7.Text = "Diesel";
            // 
            // labelDiesel
            // 
            this.labelDiesel.BackColor = System.Drawing.Color.White;
            this.labelDiesel.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDiesel.Location = new System.Drawing.Point(51, 185);
            this.labelDiesel.Name = "labelDiesel";
            this.labelDiesel.Size = new System.Drawing.Size(157, 51);
            this.labelDiesel.TabIndex = 124;
            this.labelDiesel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelOctane
            // 
            this.labelOctane.BackColor = System.Drawing.Color.White;
            this.labelOctane.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOctane.Location = new System.Drawing.Point(276, 185);
            this.labelOctane.Name = "labelOctane";
            this.labelOctane.Size = new System.Drawing.Size(157, 51);
            this.labelOctane.TabIndex = 125;
            this.labelOctane.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelPetrol
            // 
            this.labelPetrol.BackColor = System.Drawing.Color.White;
            this.labelPetrol.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPetrol.Location = new System.Drawing.Point(515, 185);
            this.labelPetrol.Name = "labelPetrol";
            this.labelPetrol.Size = new System.Drawing.Size(157, 51);
            this.labelPetrol.TabIndex = 126;
            this.labelPetrol.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelCNG
            // 
            this.labelCNG.BackColor = System.Drawing.Color.White;
            this.labelCNG.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCNG.Location = new System.Drawing.Point(745, 185);
            this.labelCNG.Name = "labelCNG";
            this.labelCNG.Size = new System.Drawing.Size(157, 51);
            this.labelCNG.TabIndex = 127;
            this.labelCNG.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(87, 253);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 25);
            this.label5.TabIndex = 128;
            this.label5.Text = "Litre";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(561, 253);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 25);
            this.label6.TabIndex = 129;
            this.label6.Text = "Litre";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(320, 253);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 25);
            this.label11.TabIndex = 130;
            this.label11.Text = "Litre";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(763, 253);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(128, 25);
            this.label12.TabIndex = 129;
            this.label12.Text = "Cubic Meter";
            // 
            // buttonHome
            // 
            this.buttonHome.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonHome.BackColor = System.Drawing.Color.Transparent;
            this.buttonHome.Font = new System.Drawing.Font("Palatino Linotype", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonHome.ForeColor = System.Drawing.Color.Black;
            this.buttonHome.Location = new System.Drawing.Point(1, -1);
            this.buttonHome.Margin = new System.Windows.Forms.Padding(1);
            this.buttonHome.Name = "buttonHome";
            this.buttonHome.Size = new System.Drawing.Size(49, 21);
            this.buttonHome.TabIndex = 132;
            this.buttonHome.Text = "Home";
            this.buttonHome.UseVisualStyleBackColor = false;
            this.buttonHome.Click += new System.EventHandler(this.buttonHome_Click);
            // 
            // buttonBackUR_L
            // 
            this.buttonBackUR_L.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonBackUR_L.BackColor = System.Drawing.Color.Transparent;
            this.buttonBackUR_L.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBackUR_L.ForeColor = System.Drawing.Color.Black;
            this.buttonBackUR_L.Location = new System.Drawing.Point(876, -2);
            this.buttonBackUR_L.Margin = new System.Windows.Forms.Padding(1);
            this.buttonBackUR_L.Name = "buttonBackUR_L";
            this.buttonBackUR_L.Size = new System.Drawing.Size(48, 21);
            this.buttonBackUR_L.TabIndex = 131;
            this.buttonBackUR_L.Text = "Back";
            this.buttonBackUR_L.UseVisualStyleBackColor = false;
            this.buttonBackUR_L.Click += new System.EventHandler(this.buttonBackUR_L_Click);
            // 
            // FormStock
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(925, 362);
            this.Controls.Add(this.buttonHome);
            this.Controls.Add(this.buttonBackUR_L);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.labelCNG);
            this.Controls.Add(this.labelPetrol);
            this.Controls.Add(this.labelOctane);
            this.Controls.Add(this.labelDiesel);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.buttonG);
            this.Controls.Add(this.labelStock);
            this.Name = "FormStock";
            this.Text = "Stock";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormStock_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelStock;
        private System.Windows.Forms.Button buttonG;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label labelDiesel;
        private System.Windows.Forms.Label labelOctane;
        private System.Windows.Forms.Label labelPetrol;
        private System.Windows.Forms.Label labelCNG;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button buttonHome;
        private System.Windows.Forms.Button buttonBackUR_L;
    }
}