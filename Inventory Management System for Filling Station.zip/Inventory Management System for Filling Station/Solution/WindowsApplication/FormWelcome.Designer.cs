﻿namespace WindowsApplication
{
    partial class FormWelcome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelWelcome = new System.Windows.Forms.Label();
            this.buttonBill = new System.Windows.Forms.Button();
            this.buttonInventory = new System.Windows.Forms.Button();
            this.buttonBackW_L = new System.Windows.Forms.Button();
            this.buttonHome = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelWelcome
            // 
            this.labelWelcome.BackColor = System.Drawing.Color.Transparent;
            this.labelWelcome.Font = new System.Drawing.Font("Modern No. 20", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelWelcome.ForeColor = System.Drawing.Color.Transparent;
            this.labelWelcome.Location = new System.Drawing.Point(160, 9);
            this.labelWelcome.Name = "labelWelcome";
            this.labelWelcome.Size = new System.Drawing.Size(717, 56);
            this.labelWelcome.TabIndex = 0;
            this.labelWelcome.Text = "Welcome To \"Amplified Filling Station\"";
            this.labelWelcome.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // buttonBill
            // 
            this.buttonBill.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonBill.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(147)))), ((int)(((byte)(144)))));
            this.buttonBill.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBill.ForeColor = System.Drawing.Color.Transparent;
            this.buttonBill.Location = new System.Drawing.Point(288, 114);
            this.buttonBill.Margin = new System.Windows.Forms.Padding(1);
            this.buttonBill.Name = "buttonBill";
            this.buttonBill.Size = new System.Drawing.Size(136, 65);
            this.buttonBill.TabIndex = 1;
            this.buttonBill.Text = "Create a Bill";
            this.buttonBill.UseVisualStyleBackColor = false;
            this.buttonBill.Click += new System.EventHandler(this.buttonBill_Click);
            // 
            // buttonInventory
            // 
            this.buttonInventory.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonInventory.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(147)))), ((int)(((byte)(144)))));
            this.buttonInventory.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonInventory.ForeColor = System.Drawing.Color.Transparent;
            this.buttonInventory.Location = new System.Drawing.Point(467, 114);
            this.buttonInventory.Margin = new System.Windows.Forms.Padding(1);
            this.buttonInventory.Name = "buttonInventory";
            this.buttonInventory.Size = new System.Drawing.Size(136, 65);
            this.buttonInventory.TabIndex = 2;
            this.buttonInventory.Text = "Watch Inventory";
            this.buttonInventory.UseVisualStyleBackColor = false;
            this.buttonInventory.Click += new System.EventHandler(this.buttonInventory_Click);
            // 
            // buttonBackW_L
            // 
            this.buttonBackW_L.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonBackW_L.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(147)))), ((int)(((byte)(144)))));
            this.buttonBackW_L.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBackW_L.ForeColor = System.Drawing.Color.Transparent;
            this.buttonBackW_L.Location = new System.Drawing.Point(496, 319);
            this.buttonBackW_L.Margin = new System.Windows.Forms.Padding(1);
            this.buttonBackW_L.Name = "buttonBackW_L";
            this.buttonBackW_L.Size = new System.Drawing.Size(75, 30);
            this.buttonBackW_L.TabIndex = 3;
            this.buttonBackW_L.Text = "Back";
            this.buttonBackW_L.UseVisualStyleBackColor = false;
            this.buttonBackW_L.Click += new System.EventHandler(this.buttonBack2_1_Click);
            // 
            // buttonHome
            // 
            this.buttonHome.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonHome.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(111)))), ((int)(((byte)(112)))), ((int)(((byte)(104)))));
            this.buttonHome.Font = new System.Drawing.Font("Palatino Linotype", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonHome.ForeColor = System.Drawing.Color.Black;
            this.buttonHome.Location = new System.Drawing.Point(0, -2);
            this.buttonHome.Margin = new System.Windows.Forms.Padding(1);
            this.buttonHome.Name = "buttonHome";
            this.buttonHome.Size = new System.Drawing.Size(49, 24);
            this.buttonHome.TabIndex = 17;
            this.buttonHome.Text = "Home";
            this.buttonHome.UseVisualStyleBackColor = false;
            this.buttonHome.Click += new System.EventHandler(this.buttonHome_Click);
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(147)))), ((int)(((byte)(144)))));
            this.button1.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Transparent;
            this.button1.Location = new System.Drawing.Point(644, 114);
            this.button1.Margin = new System.Windows.Forms.Padding(1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(136, 65);
            this.button1.TabIndex = 18;
            this.button1.Text = "Update Sell Price";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FormWelcome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(111)))), ((int)(((byte)(112)))), ((int)(((byte)(104)))));
            this.BackgroundImage = global::WindowsApplication.Properties.Resources.petronas_news_03_20130726102514h;
            this.ClientSize = new System.Drawing.Size(921, 359);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.buttonHome);
            this.Controls.Add(this.buttonBackW_L);
            this.Controls.Add(this.buttonInventory);
            this.Controls.Add(this.buttonBill);
            this.Controls.Add(this.labelWelcome);
            this.Name = "FormWelcome";
            this.Text = "Welcome";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormWelcome_FormClosing);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label labelWelcome;
        private System.Windows.Forms.Button buttonBill;
        private System.Windows.Forms.Button buttonInventory;
        private System.Windows.Forms.Button buttonBackW_L;
        private System.Windows.Forms.Button buttonHome;
        private System.Windows.Forms.Button button1;
    }
}