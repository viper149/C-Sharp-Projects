﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsApplication
{
    public partial class FormStockInventory : Form
    {
        public FormStockInventory()
        {
            InitializeComponent();
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            FormInventory ob = new FormInventory();
            ob.Show();
            this.Hide();
        }

        private void buttonHome_Click(object sender, EventArgs e)
        {
            FormLogin ob = new FormLogin();
            ob.Show();
            this.Hide();
        }

        private void buttonInput_Click(object sender, EventArgs e)
        {
            FormShowInput ob = new FormShowInput();
            ob.Show();
            this.Hide();
        }

        private void buttonOutput_Click(object sender, EventArgs e)
        {
            FormShowOutput ob = new FormShowOutput();
            ob.Show();
            this.Hide();
        }

        private void FormStockInventory_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void buttonStock_Click(object sender, EventArgs e)
        {
            FormStock ob = new FormStock();
            ob.Show();
            this.Hide();
        }
    }
}
