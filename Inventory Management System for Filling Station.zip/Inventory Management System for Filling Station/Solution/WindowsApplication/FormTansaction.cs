﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsApplication
{
    public partial class FormTansaction : Form
    {
        public FormTansaction()
        {
            InitializeComponent();
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            FormInventory ob = new FormInventory();
            ob.Show();
            this.Hide();
        }

        private void buttonHome_Click(object sender, EventArgs e)
        {
            FormLogin ob = new FormLogin();
            ob.Show();
            this.Hide();
        }

        private void FormTansaction_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //MyDBDataContext mdc = new MyDBDataContext(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\ashar\Desktop\Inventory Management System for Filling Station\Solution\WindowsApplication\db.mdf;Integrated Security=True;Connect Timeout=30");

            //InputData i = new InputData();
            //double sum = Convert.ToInt32(i.Compute("SUM(Quantity)", string.Empty));

            MessageBox.Show("Comming Soon");

        }
    }
}
