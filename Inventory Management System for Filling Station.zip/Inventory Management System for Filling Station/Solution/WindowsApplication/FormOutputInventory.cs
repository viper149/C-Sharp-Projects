﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsApplication
{
    public partial class FormOutputInventory : Form
    {
        public FormOutputInventory()
        {
            InitializeComponent();
        }

        private void FormOutputInventory_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void buttonHome_Click(object sender, EventArgs e)
        {
            FormLogin ob = new FormLogin();
            ob.Show();
            this.Hide();
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            FormStockInventory ob = new FormStockInventory();
            ob.Show();
            this.Hide();
        }

        private void buttonG_Click(object sender, EventArgs e)
        {
            label6.Text = Convert.ToString(DateTime.Today);
        }
    }
}
