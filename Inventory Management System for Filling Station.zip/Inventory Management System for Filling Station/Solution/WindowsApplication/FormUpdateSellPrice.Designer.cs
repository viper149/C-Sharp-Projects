﻿namespace WindowsApplication
{
    partial class FormUpdateSellPrice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonHome = new System.Windows.Forms.Button();
            this.buttonPConfirm = new System.Windows.Forms.Button();
            this.textBoxUPrice = new System.Windows.Forms.TextBox();
            this.comboBoxPName = new System.Windows.Forms.ComboBox();
            this.labelUPrice = new System.Windows.Forms.Label();
            this.labelPName = new System.Windows.Forms.Label();
            this.buttonBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonHome
            // 
            this.buttonHome.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonHome.BackColor = System.Drawing.Color.Transparent;
            this.buttonHome.Font = new System.Drawing.Font("Palatino Linotype", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonHome.ForeColor = System.Drawing.Color.Black;
            this.buttonHome.Location = new System.Drawing.Point(0, -1);
            this.buttonHome.Margin = new System.Windows.Forms.Padding(1);
            this.buttonHome.Name = "buttonHome";
            this.buttonHome.Size = new System.Drawing.Size(49, 21);
            this.buttonHome.TabIndex = 29;
            this.buttonHome.Text = "Home";
            this.buttonHome.UseVisualStyleBackColor = false;
            this.buttonHome.Click += new System.EventHandler(this.buttonHome_Click);
            // 
            // buttonPConfirm
            // 
            this.buttonPConfirm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonPConfirm.BackColor = System.Drawing.Color.Transparent;
            this.buttonPConfirm.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPConfirm.ForeColor = System.Drawing.Color.Black;
            this.buttonPConfirm.Location = new System.Drawing.Point(428, 253);
            this.buttonPConfirm.Margin = new System.Windows.Forms.Padding(1);
            this.buttonPConfirm.Name = "buttonPConfirm";
            this.buttonPConfirm.Size = new System.Drawing.Size(86, 30);
            this.buttonPConfirm.TabIndex = 28;
            this.buttonPConfirm.Text = "Confirm";
            this.buttonPConfirm.UseVisualStyleBackColor = false;
            this.buttonPConfirm.Click += new System.EventHandler(this.buttonPConfirm_Click);
            // 
            // textBoxUPrice
            // 
            this.textBoxUPrice.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxUPrice.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxUPrice.Location = new System.Drawing.Point(588, 142);
            this.textBoxUPrice.Name = "textBoxUPrice";
            this.textBoxUPrice.Size = new System.Drawing.Size(121, 23);
            this.textBoxUPrice.TabIndex = 25;
            this.textBoxUPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // comboBoxPName
            // 
            this.comboBoxPName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBoxPName.BackColor = System.Drawing.Color.Gainsboro;
            this.comboBoxPName.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxPName.FormattingEnabled = true;
            this.comboBoxPName.Items.AddRange(new object[] {
            "Diesel",
            "Octane",
            "Petrol",
            "CNG"});
            this.comboBoxPName.Location = new System.Drawing.Point(588, 73);
            this.comboBoxPName.Name = "comboBoxPName";
            this.comboBoxPName.Size = new System.Drawing.Size(121, 24);
            this.comboBoxPName.TabIndex = 24;
            this.comboBoxPName.Text = "Select Product";
            // 
            // labelUPrice
            // 
            this.labelUPrice.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelUPrice.BackColor = System.Drawing.Color.Transparent;
            this.labelUPrice.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUPrice.Location = new System.Drawing.Point(274, 129);
            this.labelUPrice.Name = "labelUPrice";
            this.labelUPrice.Size = new System.Drawing.Size(142, 42);
            this.labelUPrice.TabIndex = 23;
            this.labelUPrice.Text = "Unit Price";
            this.labelUPrice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelPName
            // 
            this.labelPName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelPName.BackColor = System.Drawing.Color.Transparent;
            this.labelPName.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPName.Location = new System.Drawing.Point(274, 61);
            this.labelPName.Name = "labelPName";
            this.labelPName.Size = new System.Drawing.Size(127, 42);
            this.labelPName.TabIndex = 22;
            this.labelPName.Text = "Product Name";
            this.labelPName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // buttonBack
            // 
            this.buttonBack.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(206)))), ((int)(((byte)(201)))));
            this.buttonBack.Font = new System.Drawing.Font("Palatino Linotype", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBack.ForeColor = System.Drawing.Color.Black;
            this.buttonBack.Location = new System.Drawing.Point(875, -1);
            this.buttonBack.Margin = new System.Windows.Forms.Padding(1);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(49, 21);
            this.buttonBack.TabIndex = 63;
            this.buttonBack.Text = "Back";
            this.buttonBack.UseVisualStyleBackColor = false;
            this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
            // 
            // FormUpdateSellPrice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(925, 362);
            this.Controls.Add(this.buttonBack);
            this.Controls.Add(this.buttonHome);
            this.Controls.Add(this.buttonPConfirm);
            this.Controls.Add(this.textBoxUPrice);
            this.Controls.Add(this.comboBoxPName);
            this.Controls.Add(this.labelUPrice);
            this.Controls.Add(this.labelPName);
            this.Name = "FormUpdateSellPrice";
            this.Text = "UpdateSellPrice";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormUpdateSellPrice_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonHome;
        private System.Windows.Forms.Button buttonPConfirm;
        private System.Windows.Forms.TextBox textBoxUPrice;
        private System.Windows.Forms.ComboBox comboBoxPName;
        private System.Windows.Forms.Label labelUPrice;
        private System.Windows.Forms.Label labelPName;
        private System.Windows.Forms.Button buttonBack;
    }
}