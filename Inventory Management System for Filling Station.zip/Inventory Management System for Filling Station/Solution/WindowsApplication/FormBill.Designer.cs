﻿namespace WindowsApplication
{
    partial class FormBill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelPetroleum = new System.Windows.Forms.Label();
            this.labelGasoline = new System.Windows.Forms.Label();
            this.labelPName = new System.Windows.Forms.Label();
            this.labelPQuantity = new System.Windows.Forms.Label();
            this.labelGName = new System.Windows.Forms.Label();
            this.labelGQuantity = new System.Windows.Forms.Label();
            this.comboBoxPName = new System.Windows.Forms.ComboBox();
            this.comboBoxGName = new System.Windows.Forms.ComboBox();
            this.textBoxPQuantity = new System.Windows.Forms.TextBox();
            this.textBoxGQuantity = new System.Windows.Forms.TextBox();
            this.buttonBackB_W = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonPConfirm = new System.Windows.Forms.Button();
            this.buttonGConfirm = new System.Windows.Forms.Button();
            this.buttonHome = new System.Windows.Forms.Button();
            this.labelVNoP = new System.Windows.Forms.Label();
            this.labelVNoG = new System.Windows.Forms.Label();
            this.textBoxVNoG = new System.Windows.Forms.TextBox();
            this.textBoxVNoP = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // labelPetroleum
            // 
            this.labelPetroleum.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelPetroleum.BackColor = System.Drawing.Color.Transparent;
            this.labelPetroleum.Font = new System.Drawing.Font("Modern No. 20", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPetroleum.Location = new System.Drawing.Point(90, 37);
            this.labelPetroleum.Name = "labelPetroleum";
            this.labelPetroleum.Size = new System.Drawing.Size(148, 42);
            this.labelPetroleum.TabIndex = 0;
            this.labelPetroleum.Text = "Petroleum";
            this.labelPetroleum.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelGasoline
            // 
            this.labelGasoline.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelGasoline.BackColor = System.Drawing.Color.Transparent;
            this.labelGasoline.Font = new System.Drawing.Font("Modern No. 20", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGasoline.Location = new System.Drawing.Point(623, 37);
            this.labelGasoline.Name = "labelGasoline";
            this.labelGasoline.Size = new System.Drawing.Size(148, 42);
            this.labelGasoline.TabIndex = 1;
            this.labelGasoline.Text = "Gasoline";
            this.labelGasoline.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelPName
            // 
            this.labelPName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelPName.BackColor = System.Drawing.Color.Transparent;
            this.labelPName.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPName.Location = new System.Drawing.Point(10, 103);
            this.labelPName.Name = "labelPName";
            this.labelPName.Size = new System.Drawing.Size(127, 42);
            this.labelPName.TabIndex = 2;
            this.labelPName.Text = "Product Name";
            this.labelPName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelPQuantity
            // 
            this.labelPQuantity.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelPQuantity.BackColor = System.Drawing.Color.Transparent;
            this.labelPQuantity.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPQuantity.Location = new System.Drawing.Point(10, 161);
            this.labelPQuantity.Name = "labelPQuantity";
            this.labelPQuantity.Size = new System.Drawing.Size(142, 42);
            this.labelPQuantity.TabIndex = 3;
            this.labelPQuantity.Text = "Product Quanity";
            this.labelPQuantity.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelGName
            // 
            this.labelGName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelGName.BackColor = System.Drawing.Color.Transparent;
            this.labelGName.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGName.Location = new System.Drawing.Point(541, 103);
            this.labelGName.Name = "labelGName";
            this.labelGName.Size = new System.Drawing.Size(127, 42);
            this.labelGName.TabIndex = 4;
            this.labelGName.Text = "Product Name";
            this.labelGName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelGQuantity
            // 
            this.labelGQuantity.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelGQuantity.BackColor = System.Drawing.Color.Transparent;
            this.labelGQuantity.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGQuantity.Location = new System.Drawing.Point(541, 161);
            this.labelGQuantity.Name = "labelGQuantity";
            this.labelGQuantity.Size = new System.Drawing.Size(142, 42);
            this.labelGQuantity.TabIndex = 6;
            this.labelGQuantity.Text = "Product Quanity";
            this.labelGQuantity.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // comboBoxPName
            // 
            this.comboBoxPName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBoxPName.BackColor = System.Drawing.Color.Gainsboro;
            this.comboBoxPName.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxPName.FormattingEnabled = true;
            this.comboBoxPName.Items.AddRange(new object[] {
            "Diesel",
            "Octane",
            "Petrol"});
            this.comboBoxPName.Location = new System.Drawing.Point(212, 115);
            this.comboBoxPName.Name = "comboBoxPName";
            this.comboBoxPName.Size = new System.Drawing.Size(121, 24);
            this.comboBoxPName.TabIndex = 7;
            this.comboBoxPName.Text = "Select Product";
            // 
            // comboBoxGName
            // 
            this.comboBoxGName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBoxGName.BackColor = System.Drawing.Color.Gainsboro;
            this.comboBoxGName.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxGName.FormattingEnabled = true;
            this.comboBoxGName.Items.AddRange(new object[] {
            "CNG"});
            this.comboBoxGName.Location = new System.Drawing.Point(752, 115);
            this.comboBoxGName.Name = "comboBoxGName";
            this.comboBoxGName.Size = new System.Drawing.Size(121, 24);
            this.comboBoxGName.TabIndex = 8;
            this.comboBoxGName.Text = "Select Product";
            // 
            // textBoxPQuantity
            // 
            this.textBoxPQuantity.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxPQuantity.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPQuantity.Location = new System.Drawing.Point(212, 174);
            this.textBoxPQuantity.Name = "textBoxPQuantity";
            this.textBoxPQuantity.Size = new System.Drawing.Size(121, 23);
            this.textBoxPQuantity.TabIndex = 9;
            this.textBoxPQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxGQuantity
            // 
            this.textBoxGQuantity.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxGQuantity.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxGQuantity.Location = new System.Drawing.Point(752, 174);
            this.textBoxGQuantity.Name = "textBoxGQuantity";
            this.textBoxGQuantity.Size = new System.Drawing.Size(121, 23);
            this.textBoxGQuantity.TabIndex = 10;
            this.textBoxGQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttonBackB_W
            // 
            this.buttonBackB_W.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonBackB_W.BackColor = System.Drawing.Color.Transparent;
            this.buttonBackB_W.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBackB_W.ForeColor = System.Drawing.Color.Black;
            this.buttonBackB_W.Location = new System.Drawing.Point(398, 319);
            this.buttonBackB_W.Margin = new System.Windows.Forms.Padding(1);
            this.buttonBackB_W.Name = "buttonBackB_W";
            this.buttonBackB_W.Size = new System.Drawing.Size(75, 30);
            this.buttonBackB_W.TabIndex = 11;
            this.buttonBackB_W.Text = "Back";
            this.buttonBackB_W.UseVisualStyleBackColor = false;
            this.buttonBackB_W.Click += new System.EventHandler(this.buttonBack3_2_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(27, 192);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 21);
            this.label1.TabIndex = 12;
            this.label1.Text = "(In Litre)";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(542, 192);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 21);
            this.label2.TabIndex = 13;
            this.label2.Text = "(In Cubic meter)";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // buttonPConfirm
            // 
            this.buttonPConfirm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonPConfirm.BackColor = System.Drawing.Color.Transparent;
            this.buttonPConfirm.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPConfirm.ForeColor = System.Drawing.Color.Black;
            this.buttonPConfirm.Location = new System.Drawing.Point(96, 296);
            this.buttonPConfirm.Margin = new System.Windows.Forms.Padding(1);
            this.buttonPConfirm.Name = "buttonPConfirm";
            this.buttonPConfirm.Size = new System.Drawing.Size(86, 30);
            this.buttonPConfirm.TabIndex = 14;
            this.buttonPConfirm.Text = "Confirm";
            this.buttonPConfirm.UseVisualStyleBackColor = false;
            this.buttonPConfirm.Click += new System.EventHandler(this.buttonPConfirm_Click);
            // 
            // buttonGConfirm
            // 
            this.buttonGConfirm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonGConfirm.BackColor = System.Drawing.Color.Transparent;
            this.buttonGConfirm.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonGConfirm.ForeColor = System.Drawing.Color.Black;
            this.buttonGConfirm.Location = new System.Drawing.Point(660, 296);
            this.buttonGConfirm.Margin = new System.Windows.Forms.Padding(1);
            this.buttonGConfirm.Name = "buttonGConfirm";
            this.buttonGConfirm.Size = new System.Drawing.Size(86, 30);
            this.buttonGConfirm.TabIndex = 15;
            this.buttonGConfirm.Text = "Confirm";
            this.buttonGConfirm.UseVisualStyleBackColor = false;
            this.buttonGConfirm.Click += new System.EventHandler(this.buttonGConfirm_Click);
            // 
            // buttonHome
            // 
            this.buttonHome.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonHome.BackColor = System.Drawing.Color.Transparent;
            this.buttonHome.Font = new System.Drawing.Font("Palatino Linotype", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonHome.ForeColor = System.Drawing.Color.Black;
            this.buttonHome.Location = new System.Drawing.Point(-1, -3);
            this.buttonHome.Margin = new System.Windows.Forms.Padding(1);
            this.buttonHome.Name = "buttonHome";
            this.buttonHome.Size = new System.Drawing.Size(49, 21);
            this.buttonHome.TabIndex = 16;
            this.buttonHome.Text = "Home";
            this.buttonHome.UseVisualStyleBackColor = false;
            this.buttonHome.Click += new System.EventHandler(this.buttonHome_Click);
            // 
            // labelVNoP
            // 
            this.labelVNoP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelVNoP.BackColor = System.Drawing.Color.Transparent;
            this.labelVNoP.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVNoP.Location = new System.Drawing.Point(10, 225);
            this.labelVNoP.Name = "labelVNoP";
            this.labelVNoP.Size = new System.Drawing.Size(127, 42);
            this.labelVNoP.TabIndex = 17;
            this.labelVNoP.Text = "Vehicle No";
            this.labelVNoP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelVNoG
            // 
            this.labelVNoG.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelVNoG.BackColor = System.Drawing.Color.Transparent;
            this.labelVNoG.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVNoG.Location = new System.Drawing.Point(541, 225);
            this.labelVNoG.Name = "labelVNoG";
            this.labelVNoG.Size = new System.Drawing.Size(127, 42);
            this.labelVNoG.TabIndex = 18;
            this.labelVNoG.Text = "Vehicle No";
            this.labelVNoG.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxVNoG
            // 
            this.textBoxVNoG.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxVNoG.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxVNoG.Location = new System.Drawing.Point(686, 238);
            this.textBoxVNoG.Name = "textBoxVNoG";
            this.textBoxVNoG.Size = new System.Drawing.Size(187, 23);
            this.textBoxVNoG.TabIndex = 19;
            this.textBoxVNoG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxVNoP
            // 
            this.textBoxVNoP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxVNoP.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxVNoP.Location = new System.Drawing.Point(158, 238);
            this.textBoxVNoP.Name = "textBoxVNoP";
            this.textBoxVNoP.Size = new System.Drawing.Size(175, 23);
            this.textBoxVNoP.TabIndex = 20;
            this.textBoxVNoP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // FormBill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(925, 358);
            this.Controls.Add(this.textBoxVNoP);
            this.Controls.Add(this.textBoxVNoG);
            this.Controls.Add(this.labelVNoG);
            this.Controls.Add(this.labelVNoP);
            this.Controls.Add(this.buttonHome);
            this.Controls.Add(this.buttonGConfirm);
            this.Controls.Add(this.buttonPConfirm);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonBackB_W);
            this.Controls.Add(this.textBoxGQuantity);
            this.Controls.Add(this.textBoxPQuantity);
            this.Controls.Add(this.comboBoxGName);
            this.Controls.Add(this.comboBoxPName);
            this.Controls.Add(this.labelGQuantity);
            this.Controls.Add(this.labelGName);
            this.Controls.Add(this.labelPQuantity);
            this.Controls.Add(this.labelPName);
            this.Controls.Add(this.labelGasoline);
            this.Controls.Add(this.labelPetroleum);
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "FormBill";
            this.Text = "FormBill";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormBill_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelPetroleum;
        private System.Windows.Forms.Label labelGasoline;
        private System.Windows.Forms.Label labelPName;
        private System.Windows.Forms.Label labelPQuantity;
        private System.Windows.Forms.Label labelGName;
        private System.Windows.Forms.Label labelGQuantity;
        private System.Windows.Forms.ComboBox comboBoxPName;
        private System.Windows.Forms.ComboBox comboBoxGName;
        private System.Windows.Forms.TextBox textBoxPQuantity;
        private System.Windows.Forms.TextBox textBoxGQuantity;
        private System.Windows.Forms.Button buttonBackB_W;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonPConfirm;
        private System.Windows.Forms.Button buttonGConfirm;
        private System.Windows.Forms.Button buttonHome;
        private System.Windows.Forms.Label labelVNoP;
        private System.Windows.Forms.Label labelVNoG;
        private System.Windows.Forms.TextBox textBoxVNoG;
        private System.Windows.Forms.TextBox textBoxVNoP;
    }
}