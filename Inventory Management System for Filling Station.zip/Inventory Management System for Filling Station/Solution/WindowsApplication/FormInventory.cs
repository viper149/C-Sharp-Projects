﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsApplication
{
    public partial class FormInventory : Form
    {
        public FormInventory()
        {
            InitializeComponent();
        }

        private void FormInventory_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void buttonBackW_L_Click(object sender, EventArgs e)
        {
            FormWelcome ob = new FormWelcome();
            ob.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormLogin ob = new FormLogin();
            ob.Show();
            this.Hide();
        }

        private void buttonAddInv_Click(object sender, EventArgs e)
        {
            FormAddInventory ob = new FormAddInventory();
            ob.Show();
            this.Hide();
        }

        private void buttonTrans_Click(object sender, EventArgs e)
        {
            FormTansaction ob = new FormTansaction();
            ob.Show();
            this.Hide();
        }

        private void buttonStockInv_Click(object sender, EventArgs e)
        {
            FormStockInventory ob = new FormStockInventory();
            ob.Show();
            this.Hide();
        }
    }
}
