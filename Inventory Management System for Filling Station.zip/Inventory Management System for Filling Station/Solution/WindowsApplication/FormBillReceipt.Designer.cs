﻿namespace WindowsApplication
{
    partial class FormBillReceipt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.labelTotalCost = new System.Windows.Forms.Label();
            this.labelUPrice = new System.Windows.Forms.Label();
            this.labelQuantity = new System.Windows.Forms.Label();
            this.labelPName = new System.Windows.Forms.Label();
            this.labelVNo = new System.Windows.Forms.Label();
            this.labelDate = new System.Windows.Forms.Label();
            this.labelTime = new System.Windows.Forms.Label();
            this.buttonHome = new System.Windows.Forms.Button();
            this.buttonBackUR_L = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(147, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 35);
            this.label1.TabIndex = 0;
            this.label1.Text = "Date :";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 307);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(273, 35);
            this.label2.TabIndex = 1;
            this.label2.Text = "Total Cost :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label
            // 
            this.label.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.Location = new System.Drawing.Point(12, 257);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(273, 35);
            this.label.TabIndex = 2;
            this.label.Text = "Unit Price (Including 5% VAT) :";
            this.label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 207);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(273, 35);
            this.label4.TabIndex = 3;
            this.label4.Text = "Quantity :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 157);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(273, 35);
            this.label5.TabIndex = 4;
            this.label5.Text = "Product Name :";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 107);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(257, 35);
            this.label6.TabIndex = 5;
            this.label6.Text = "Vehicle No :";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(147, 44);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 35);
            this.label7.TabIndex = 6;
            this.label7.Text = "Time :";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelTotalCost
            // 
            this.labelTotalCost.BackColor = System.Drawing.Color.Gainsboro;
            this.labelTotalCost.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotalCost.Location = new System.Drawing.Point(385, 307);
            this.labelTotalCost.Name = "labelTotalCost";
            this.labelTotalCost.Size = new System.Drawing.Size(257, 35);
            this.labelTotalCost.TabIndex = 7;
            this.labelTotalCost.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelUPrice
            // 
            this.labelUPrice.BackColor = System.Drawing.Color.Gainsboro;
            this.labelUPrice.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUPrice.Location = new System.Drawing.Point(385, 257);
            this.labelUPrice.Name = "labelUPrice";
            this.labelUPrice.Size = new System.Drawing.Size(257, 35);
            this.labelUPrice.TabIndex = 8;
            this.labelUPrice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelQuantity
            // 
            this.labelQuantity.BackColor = System.Drawing.Color.Gainsboro;
            this.labelQuantity.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelQuantity.Location = new System.Drawing.Point(385, 207);
            this.labelQuantity.Name = "labelQuantity";
            this.labelQuantity.Size = new System.Drawing.Size(257, 35);
            this.labelQuantity.TabIndex = 9;
            this.labelQuantity.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelPName
            // 
            this.labelPName.BackColor = System.Drawing.Color.Gainsboro;
            this.labelPName.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPName.Location = new System.Drawing.Point(385, 157);
            this.labelPName.Name = "labelPName";
            this.labelPName.Size = new System.Drawing.Size(257, 35);
            this.labelPName.TabIndex = 10;
            this.labelPName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelVNo
            // 
            this.labelVNo.BackColor = System.Drawing.Color.Gainsboro;
            this.labelVNo.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVNo.Location = new System.Drawing.Point(385, 107);
            this.labelVNo.Name = "labelVNo";
            this.labelVNo.Size = new System.Drawing.Size(257, 35);
            this.labelVNo.TabIndex = 11;
            this.labelVNo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelDate
            // 
            this.labelDate.BackColor = System.Drawing.Color.Gainsboro;
            this.labelDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDate.Location = new System.Drawing.Point(209, 14);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(206, 25);
            this.labelDate.TabIndex = 13;
            this.labelDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelTime
            // 
            this.labelTime.BackColor = System.Drawing.Color.Gainsboro;
            this.labelTime.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTime.Location = new System.Drawing.Point(209, 48);
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(206, 26);
            this.labelTime.TabIndex = 14;
            this.labelTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // buttonHome
            // 
            this.buttonHome.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonHome.BackColor = System.Drawing.Color.Transparent;
            this.buttonHome.Font = new System.Drawing.Font("Palatino Linotype", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonHome.ForeColor = System.Drawing.Color.Black;
            this.buttonHome.Location = new System.Drawing.Point(1, -1);
            this.buttonHome.Margin = new System.Windows.Forms.Padding(1);
            this.buttonHome.Name = "buttonHome";
            this.buttonHome.Size = new System.Drawing.Size(49, 21);
            this.buttonHome.TabIndex = 133;
            this.buttonHome.Text = "Home";
            this.buttonHome.UseVisualStyleBackColor = false;
            this.buttonHome.Click += new System.EventHandler(this.buttonHome_Click);
            // 
            // buttonBackUR_L
            // 
            this.buttonBackUR_L.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonBackUR_L.BackColor = System.Drawing.Color.Transparent;
            this.buttonBackUR_L.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBackUR_L.ForeColor = System.Drawing.Color.Black;
            this.buttonBackUR_L.Location = new System.Drawing.Point(669, -2);
            this.buttonBackUR_L.Margin = new System.Windows.Forms.Padding(1);
            this.buttonBackUR_L.Name = "buttonBackUR_L";
            this.buttonBackUR_L.Size = new System.Drawing.Size(48, 21);
            this.buttonBackUR_L.TabIndex = 134;
            this.buttonBackUR_L.Text = "Back";
            this.buttonBackUR_L.UseVisualStyleBackColor = false;
            this.buttonBackUR_L.Click += new System.EventHandler(this.buttonBackUR_L_Click);
            // 
            // FormBillReceipt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(718, 364);
            this.Controls.Add(this.buttonBackUR_L);
            this.Controls.Add(this.buttonHome);
            this.Controls.Add(this.labelTime);
            this.Controls.Add(this.labelDate);
            this.Controls.Add(this.labelVNo);
            this.Controls.Add(this.labelPName);
            this.Controls.Add(this.labelQuantity);
            this.Controls.Add(this.labelUPrice);
            this.Controls.Add(this.labelTotalCost);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FormBillReceipt";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormBillReceipt_FormClosing);
            this.Load += new System.EventHandler(this.FormBillReceipt_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label labelTotalCost;
        private System.Windows.Forms.Label labelUPrice;
        private System.Windows.Forms.Label labelQuantity;
        private System.Windows.Forms.Label labelPName;
        private System.Windows.Forms.Label labelVNo;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.Label labelTime;
        private System.Windows.Forms.Button buttonHome;
        private System.Windows.Forms.Button buttonBackUR_L;
    }
}