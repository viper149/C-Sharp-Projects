﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsApplication
{
    public partial class FormShowOutput : Form
    {
        public FormShowOutput()
        {
            InitializeComponent();
        }

        private void buttonHome_Click(object sender, EventArgs e)
        {
            FormLogin ob = new FormLogin();
            ob.Show();
            this.Hide();
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            FormStockInventory ob = new FormStockInventory();
            ob.Show();
            this.Hide();
        }

        private void FormShowOutput_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void FormShowOutput_Load(object sender, EventArgs e)
        {
            GridViewUpdate();
        }

        public void GridViewUpdate()
        {
            MyDBDataContext mdc = new MyDBDataContext(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\ashar\Desktop\Inventory Management System for Filling Station\Solution\WindowsApplication\db.mdf;Integrated Security=True;Connect Timeout=30");
            var record = from a in mdc.OutputDatas
                         select a;
            dataGridView1.DataSource = record;
        }
    }
}
