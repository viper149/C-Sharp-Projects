﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace WindowsApplication
{
    public partial class FormBill : Form
    {
        public static int sl;
        public FormBill()
        {
            InitializeComponent();
        }

        private void FormBill_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void buttonBack3_2_Click(object sender, EventArgs e)
        {
            FormWelcome ob = new FormWelcome();
            ob.Show();
            this.Hide();
        }

        public void BillCreate(string n,string q,string vNo)  // n for PName,q for quantity, vNO for Vehicle no
        {
            if (vNo == null || q == null)
            {
                MessageBox.Show("Invalid Input!!", "Warning");
            }
            else
            {
                MyDBDataContext mdc = new MyDBDataContext(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\ashar\Desktop\Inventory Management System for Filling Station\Solution\WindowsApplication\db.mdf;Integrated Security=True;Connect Timeout=30");
                var record1 = from a in mdc.Prices
                              where a.PName == n
                              select a;
                InputData i = new InputData();

                Price p = record1.First();

                if (p.Available >= Convert.ToDouble(q))
                {
                    if (p.Available <= 500)
                        MessageBox.Show("Your Stock is Getting Low!You should add inventory as soon as possible!!!", "Warning");

                    i.Date = DateTime.Now.Date;
                    i.Time = DateTime.Now.TimeOfDay;
                    i.PName = n;
                    i.VNo = vNo;
                    i.Quantity = Convert.ToDouble(q);
                    i.TotalCost = i.Quantity * Convert.ToDouble(record1.First().UnitPrice);
                    mdc.InputDatas.InsertOnSubmit(i);
                    mdc.SubmitChanges();

                    p.Available -= Convert.ToDouble(q);
                    mdc.SubmitChanges();

                    q = vNo = null;
                    MessageBox.Show("Bill created successfully.");
                    sl = i.SL;
                    DialogResult d = MessageBox.Show("Do you want Receipt?", "Receipt", MessageBoxButtons.YesNo);
                    if (d == DialogResult.Yes)
                    {
                        FormBillReceipt ob = new FormBillReceipt();
                        ob.Show();
                        this.Hide();
                    }
                }
                     else
                          MessageBox.Show("Insufficient Fund!!!!!!!!", "Error");
             }
        }

        private void buttonPConfirm_Click(object sender, EventArgs e)
        {
             BillCreate(comboBoxPName.Text, textBoxPQuantity.Text,textBoxVNoP.Text);
        }

        private void buttonGConfirm_Click(object sender, EventArgs e)
        {
             BillCreate(comboBoxGName.Text, textBoxGQuantity.Text, textBoxVNoG.Text);
        }

        private void buttonHome_Click(object sender, EventArgs e)
        {
            FormLogin ob = new FormLogin();
            ob.Show();
            this.Hide();
        }
    }
}
