﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsApplication
{
    public partial class FormUpdateSellPrice : Form
    {
        public FormUpdateSellPrice()
        {
            InitializeComponent();
        }

        private void FormUpdateSellPrice_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void buttonHome_Click(object sender, EventArgs e)
        {
            FormLogin ob = new FormLogin();
            ob.Show();
            this.Hide();
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            FormWelcome ob = new FormWelcome();
            ob.Show();
            this.Hide();
        }

        private void buttonPConfirm_Click(object sender, EventArgs e)
        {
            MyDBDataContext mdc = new MyDBDataContext(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\ashar\Desktop\Inventory Management System for Filling Station\Solution\WindowsApplication\db.mdf;Integrated Security=True;Connect Timeout=30");
            var record = from a in mdc.Prices
                         where a.PName == comboBoxPName.Text
                         select a;

            Price p = record.First();
            p.UnitPrice = Convert.ToDouble(textBoxUPrice.Text);
            mdc.SubmitChanges();
            MessageBox.Show("Unit Price Updated Successfully");
            textBoxUPrice.Text = null;
        }
    }
}
