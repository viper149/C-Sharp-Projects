﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsApplication
{
    public partial class FormAddInventory : Form
    {
        public FormAddInventory()
        {
            InitializeComponent();
        }

        private void FormAddInventory_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            FormInventory ob = new FormInventory();
            ob.Show();
            this.Hide();
        }

        private void buttonHome_Click_1(object sender, EventArgs e)
        {
            FormLogin ob = new FormLogin();
            ob.Show();
            this.Hide();
        }

        private void labelTCost2_Click(object sender, EventArgs e)
        {
            labelTCost2.Text = Convert.ToString(Convert.ToDouble(textBoxQuantity.Text) * Convert.ToDouble(textBoxUCost.Text));

            if (textBoxTruck.Text == null || textBoxQuantity.Text == null || textBoxUCost.Text == null)
            {
                MessageBox.Show("Invalid Input!!", "Warning");
            }
            else
            {
                MyDBDataContext mdc = new MyDBDataContext(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\ashar\Desktop\Inventory Management System for Filling Station\Solution\WindowsApplication\db.mdf;Integrated Security=True;Connect Timeout=30");
                OutputData o = new OutputData();
                o.Date = DateTime.Now;
                o.Time = DateTime.Now.TimeOfDay;
                o.PName = comboBoxPName.Text;
                o.VNo = textBoxTruck.Text;
                o.Quantity = Convert.ToDouble(textBoxQuantity.Text);
                o.UPrice = Convert.ToDouble(textBoxUCost.Text);
                o.TotalCost = Convert.ToDouble(labelTCost2.Text);

                mdc.OutputDatas.InsertOnSubmit(o);
                mdc.SubmitChanges();

                var record = from a in mdc.Prices
                              where a.PName == comboBoxPName.Text
                              select a;
                record.First().Available += Convert.ToDouble(textBoxQuantity.Text);
                mdc.SubmitChanges();

                textBoxTruck.Text = textBoxQuantity.Text = textBoxUCost.Text = null;
                MessageBox.Show("Inventory added successfully.");
                labelTCost2.Text = "GENERATE";
            }
        }
    }
}
