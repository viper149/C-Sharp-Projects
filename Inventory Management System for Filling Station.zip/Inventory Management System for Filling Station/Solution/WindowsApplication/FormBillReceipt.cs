﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsApplication
{
    public partial class FormBillReceipt : Form
    {
        public FormBillReceipt()
        {
            InitializeComponent();
        }

        private void FormBillReceipt_Load(object sender, EventArgs e)
        {
            MyDBDataContext mdc = new MyDBDataContext(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\ashar\Desktop\Inventory Management System for Filling Station\Solution\WindowsApplication\db.mdf;Integrated Security=True;Connect Timeout=30");
            var record1 = from a in mdc.InputDatas
                          where a.SL == FormBill.sl
                          select a;

            InputData i = record1.First();

            var record2 = from a in mdc.Prices
                             where a.PName ==i.PName
                             select a;

            labelDate.Text = Convert.ToString(DateTime.Now.ToShortDateString());
            labelTime.Text = Convert.ToString(DateTime.Now.ToShortTimeString());

            labelVNo.Text = i.VNo;
            labelPName.Text = i.PName;
            labelQuantity.Text = Convert.ToString(i.Quantity);
            labelUPrice.Text = Convert.ToString(record2.First().UnitPrice);
            labelTotalCost.Text = Convert.ToString(i.TotalCost);



        }

        private void FormBillReceipt_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void buttonBackUR_L_Click(object sender, EventArgs e)
        {
            FormBill ob = new FormBill();
            ob.Show();
            this.Hide();
        }

        private void buttonHome_Click(object sender, EventArgs e)
        {
            FormLogin ob = new FormLogin();
            ob.Show();
            this.Hide();
        }
    }
}
