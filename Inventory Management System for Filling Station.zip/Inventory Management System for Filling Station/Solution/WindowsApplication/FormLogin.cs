﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsApplication
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
            this.BackgroundImage = Properties.Resources._1196415_9199b830;
            Timer t = new Timer();
            t.Interval = 6000;
            t.Tick += new EventHandler(ChangeImage);
            t.Start();
        }

        private void ChangeImage(object sender, EventArgs e)
        {
            List<Bitmap> b1 = new List<Bitmap>();
            b1.Add(Properties.Resources._1196415_9199b830);
            b1.Add(Properties.Resources.gas_station_000002993597);
            b1.Add(Properties.Resources.petrol_710x300);
            b1.Add(Properties.Resources.petronas_news_03_20130726102514h);
            b1.Add(Properties.Resources.LNG_CNG_08);

            int index = DateTime.Now.Second % b1.Count;
            this.BackgroundImage = b1[index];
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            MyDBDataContext mdc = new MyDBDataContext(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\ashar\Desktop\Inventory Management System for Filling Station\Solution\WindowsApplication\db.mdf;Integrated Security=True;Connect Timeout=30");
            var record = from a in mdc.IdPasses
                         select a;

            if (textBoxUser.Text == record.First().Id && textBoxPass.Text == record.First().Password)
            {
                MessageBox.Show("Login Successful");
                FormWelcome ob = new FormWelcome();
                ob.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid Username Or Password");
                textBoxUser.Text = null;
                textBoxPass.Text = null;
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            textBoxUser.Text = null;
            textBoxPass.Text = null;
        }

        private void FormLogin_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void buttonUR_Click(object sender, EventArgs e)
        {
            UpdateReset ob = new UpdateReset();
            ob.Show();
            this.Hide();
        }
    }
}
