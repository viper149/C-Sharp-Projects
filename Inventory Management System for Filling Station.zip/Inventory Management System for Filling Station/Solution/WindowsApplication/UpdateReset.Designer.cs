﻿namespace WindowsApplication
{
    partial class UpdateReset
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radioButtonUpdate = new System.Windows.Forms.RadioButton();
            this.radioButtonReset = new System.Windows.Forms.RadioButton();
            this.labelOldPass = new System.Windows.Forms.Label();
            this.labelConfirmPassP = new System.Windows.Forms.Label();
            this.labelNewPassP = new System.Windows.Forms.Label();
            this.labelProKey = new System.Windows.Forms.Label();
            this.textBoxConfirmPassP = new System.Windows.Forms.TextBox();
            this.textBoxNewPassP = new System.Windows.Forms.TextBox();
            this.textBoxOldpass = new System.Windows.Forms.TextBox();
            this.textBoxProKey = new System.Windows.Forms.TextBox();
            this.labelNewPassR = new System.Windows.Forms.Label();
            this.labelConfirmPassR = new System.Windows.Forms.Label();
            this.textBoxConfirmPassR = new System.Windows.Forms.TextBox();
            this.textBoxNewPassR = new System.Windows.Forms.TextBox();
            this.buttonConfirm = new System.Windows.Forms.Button();
            this.buttonBackUR_L = new System.Windows.Forms.Button();
            this.buttonHome = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // radioButtonUpdate
            // 
            this.radioButtonUpdate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.radioButtonUpdate.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonUpdate.Location = new System.Drawing.Point(111, 28);
            this.radioButtonUpdate.Name = "radioButtonUpdate";
            this.radioButtonUpdate.Size = new System.Drawing.Size(104, 24);
            this.radioButtonUpdate.TabIndex = 1;
            this.radioButtonUpdate.Text = "Update";
            this.radioButtonUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.radioButtonUpdate.UseVisualStyleBackColor = true;
            this.radioButtonUpdate.CheckedChanged += new System.EventHandler(this.radioButtonUpdate_CheckedChanged);
            // 
            // radioButtonReset
            // 
            this.radioButtonReset.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.radioButtonReset.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonReset.Location = new System.Drawing.Point(598, 28);
            this.radioButtonReset.Name = "radioButtonReset";
            this.radioButtonReset.Size = new System.Drawing.Size(104, 24);
            this.radioButtonReset.TabIndex = 1;
            this.radioButtonReset.Text = "Reset";
            this.radioButtonReset.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.radioButtonReset.UseVisualStyleBackColor = true;
            this.radioButtonReset.CheckedChanged += new System.EventHandler(this.radioButtonReset_CheckedChanged);
            // 
            // labelOldPass
            // 
            this.labelOldPass.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelOldPass.Font = new System.Drawing.Font("Georgia", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOldPass.Location = new System.Drawing.Point(108, 119);
            this.labelOldPass.Name = "labelOldPass";
            this.labelOldPass.Size = new System.Drawing.Size(147, 23);
            this.labelOldPass.TabIndex = 2;
            this.labelOldPass.Text = "Enter Old Password";
            this.labelOldPass.Visible = false;
            // 
            // labelConfirmPassP
            // 
            this.labelConfirmPassP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelConfirmPassP.Font = new System.Drawing.Font("Georgia", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelConfirmPassP.Location = new System.Drawing.Point(108, 211);
            this.labelConfirmPassP.Name = "labelConfirmPassP";
            this.labelConfirmPassP.Size = new System.Drawing.Size(166, 23);
            this.labelConfirmPassP.TabIndex = 3;
            this.labelConfirmPassP.Text = "Confirm New Password";
            this.labelConfirmPassP.Visible = false;
            // 
            // labelNewPassP
            // 
            this.labelNewPassP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelNewPassP.Font = new System.Drawing.Font("Georgia", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNewPassP.Location = new System.Drawing.Point(108, 163);
            this.labelNewPassP.Name = "labelNewPassP";
            this.labelNewPassP.Size = new System.Drawing.Size(147, 23);
            this.labelNewPassP.TabIndex = 4;
            this.labelNewPassP.Text = "Enter New Password";
            this.labelNewPassP.Visible = false;
            // 
            // labelProKey
            // 
            this.labelProKey.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelProKey.Font = new System.Drawing.Font("Georgia", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelProKey.Location = new System.Drawing.Point(595, 119);
            this.labelProKey.Name = "labelProKey";
            this.labelProKey.Size = new System.Drawing.Size(147, 23);
            this.labelProKey.TabIndex = 5;
            this.labelProKey.Text = "Enter Product Key";
            this.labelProKey.Visible = false;
            // 
            // textBoxConfirmPassP
            // 
            this.textBoxConfirmPassP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxConfirmPassP.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.textBoxConfirmPassP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxConfirmPassP.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.textBoxConfirmPassP.Location = new System.Drawing.Point(302, 211);
            this.textBoxConfirmPassP.Name = "textBoxConfirmPassP";
            this.textBoxConfirmPassP.PasswordChar = '*';
            this.textBoxConfirmPassP.Size = new System.Drawing.Size(153, 22);
            this.textBoxConfirmPassP.TabIndex = 6;
            this.textBoxConfirmPassP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxConfirmPassP.Visible = false;
            // 
            // textBoxNewPassP
            // 
            this.textBoxNewPassP.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxNewPassP.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.textBoxNewPassP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNewPassP.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.textBoxNewPassP.Location = new System.Drawing.Point(302, 163);
            this.textBoxNewPassP.Name = "textBoxNewPassP";
            this.textBoxNewPassP.PasswordChar = '*';
            this.textBoxNewPassP.Size = new System.Drawing.Size(153, 22);
            this.textBoxNewPassP.TabIndex = 7;
            this.textBoxNewPassP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxNewPassP.Visible = false;
            // 
            // textBoxOldpass
            // 
            this.textBoxOldpass.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxOldpass.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.textBoxOldpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxOldpass.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.textBoxOldpass.Location = new System.Drawing.Point(302, 118);
            this.textBoxOldpass.Name = "textBoxOldpass";
            this.textBoxOldpass.PasswordChar = '*';
            this.textBoxOldpass.Size = new System.Drawing.Size(153, 22);
            this.textBoxOldpass.TabIndex = 8;
            this.textBoxOldpass.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxOldpass.Visible = false;
            // 
            // textBoxProKey
            // 
            this.textBoxProKey.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxProKey.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.textBoxProKey.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxProKey.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.textBoxProKey.Location = new System.Drawing.Point(766, 118);
            this.textBoxProKey.Name = "textBoxProKey";
            this.textBoxProKey.Size = new System.Drawing.Size(223, 22);
            this.textBoxProKey.TabIndex = 9;
            this.textBoxProKey.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxProKey.Visible = false;
            // 
            // labelNewPassR
            // 
            this.labelNewPassR.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelNewPassR.Font = new System.Drawing.Font("Georgia", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNewPassR.Location = new System.Drawing.Point(595, 164);
            this.labelNewPassR.Name = "labelNewPassR";
            this.labelNewPassR.Size = new System.Drawing.Size(147, 23);
            this.labelNewPassR.TabIndex = 10;
            this.labelNewPassR.Text = "Enter New Password";
            this.labelNewPassR.Visible = false;
            // 
            // labelConfirmPassR
            // 
            this.labelConfirmPassR.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelConfirmPassR.Font = new System.Drawing.Font("Georgia", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelConfirmPassR.Location = new System.Drawing.Point(595, 212);
            this.labelConfirmPassR.Name = "labelConfirmPassR";
            this.labelConfirmPassR.Size = new System.Drawing.Size(166, 23);
            this.labelConfirmPassR.TabIndex = 11;
            this.labelConfirmPassR.Text = "Confirm New Password";
            this.labelConfirmPassR.Visible = false;
            // 
            // textBoxConfirmPassR
            // 
            this.textBoxConfirmPassR.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxConfirmPassR.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.textBoxConfirmPassR.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxConfirmPassR.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.textBoxConfirmPassR.Location = new System.Drawing.Point(836, 210);
            this.textBoxConfirmPassR.Name = "textBoxConfirmPassR";
            this.textBoxConfirmPassR.PasswordChar = '*';
            this.textBoxConfirmPassR.Size = new System.Drawing.Size(153, 22);
            this.textBoxConfirmPassR.TabIndex = 12;
            this.textBoxConfirmPassR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxConfirmPassR.Visible = false;
            // 
            // textBoxNewPassR
            // 
            this.textBoxNewPassR.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBoxNewPassR.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.textBoxNewPassR.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNewPassR.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.textBoxNewPassR.Location = new System.Drawing.Point(836, 162);
            this.textBoxNewPassR.Name = "textBoxNewPassR";
            this.textBoxNewPassR.PasswordChar = '*';
            this.textBoxNewPassR.Size = new System.Drawing.Size(153, 22);
            this.textBoxNewPassR.TabIndex = 13;
            this.textBoxNewPassR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxNewPassR.Visible = false;
            // 
            // buttonConfirm
            // 
            this.buttonConfirm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonConfirm.BackColor = System.Drawing.Color.Transparent;
            this.buttonConfirm.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonConfirm.ForeColor = System.Drawing.Color.Black;
            this.buttonConfirm.Location = new System.Drawing.Point(502, 300);
            this.buttonConfirm.Margin = new System.Windows.Forms.Padding(1);
            this.buttonConfirm.Name = "buttonConfirm";
            this.buttonConfirm.Size = new System.Drawing.Size(86, 30);
            this.buttonConfirm.TabIndex = 15;
            this.buttonConfirm.Text = "Confirm";
            this.buttonConfirm.UseVisualStyleBackColor = false;
            this.buttonConfirm.Visible = false;
            this.buttonConfirm.Click += new System.EventHandler(this.buttonPConfirm_Click);
            // 
            // buttonBackUR_L
            // 
            this.buttonBackUR_L.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonBackUR_L.BackColor = System.Drawing.Color.Transparent;
            this.buttonBackUR_L.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBackUR_L.ForeColor = System.Drawing.Color.Black;
            this.buttonBackUR_L.Location = new System.Drawing.Point(130, 301);
            this.buttonBackUR_L.Margin = new System.Windows.Forms.Padding(1);
            this.buttonBackUR_L.Name = "buttonBackUR_L";
            this.buttonBackUR_L.Size = new System.Drawing.Size(45, 30);
            this.buttonBackUR_L.TabIndex = 16;
            this.buttonBackUR_L.Text = "Back";
            this.buttonBackUR_L.UseVisualStyleBackColor = false;
            this.buttonBackUR_L.Click += new System.EventHandler(this.buttonBackUR_L_Click);
            // 
            // buttonHome
            // 
            this.buttonHome.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonHome.BackColor = System.Drawing.Color.Transparent;
            this.buttonHome.Font = new System.Drawing.Font("Palatino Linotype", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonHome.ForeColor = System.Drawing.Color.Black;
            this.buttonHome.Location = new System.Drawing.Point(-1, -4);
            this.buttonHome.Margin = new System.Windows.Forms.Padding(1);
            this.buttonHome.Name = "buttonHome";
            this.buttonHome.Size = new System.Drawing.Size(49, 21);
            this.buttonHome.TabIndex = 17;
            this.buttonHome.Text = "Home";
            this.buttonHome.UseVisualStyleBackColor = false;
            this.buttonHome.Click += new System.EventHandler(this.button1_Click);
            // 
            // UpdateReset
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1069, 354);
            this.Controls.Add(this.buttonHome);
            this.Controls.Add(this.buttonBackUR_L);
            this.Controls.Add(this.buttonConfirm);
            this.Controls.Add(this.textBoxNewPassR);
            this.Controls.Add(this.textBoxConfirmPassR);
            this.Controls.Add(this.labelConfirmPassR);
            this.Controls.Add(this.labelNewPassR);
            this.Controls.Add(this.textBoxProKey);
            this.Controls.Add(this.textBoxOldpass);
            this.Controls.Add(this.textBoxNewPassP);
            this.Controls.Add(this.textBoxConfirmPassP);
            this.Controls.Add(this.labelProKey);
            this.Controls.Add(this.labelNewPassP);
            this.Controls.Add(this.labelConfirmPassP);
            this.Controls.Add(this.labelOldPass);
            this.Controls.Add(this.radioButtonReset);
            this.Controls.Add(this.radioButtonUpdate);
            this.Name = "UpdateReset";
            this.Text = "UpdateReset";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.UpdateReset_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radioButtonUpdate;
        private System.Windows.Forms.RadioButton radioButtonReset;
        private System.Windows.Forms.Label labelOldPass;
        private System.Windows.Forms.Label labelConfirmPassP;
        private System.Windows.Forms.Label labelNewPassP;
        private System.Windows.Forms.Label labelProKey;
        private System.Windows.Forms.TextBox textBoxConfirmPassP;
        private System.Windows.Forms.TextBox textBoxNewPassP;
        private System.Windows.Forms.TextBox textBoxOldpass;
        private System.Windows.Forms.TextBox textBoxProKey;
        private System.Windows.Forms.Label labelNewPassR;
        private System.Windows.Forms.Label labelConfirmPassR;
        private System.Windows.Forms.TextBox textBoxConfirmPassR;
        private System.Windows.Forms.TextBox textBoxNewPassR;
        private System.Windows.Forms.Button buttonConfirm;
        private System.Windows.Forms.Button buttonBackUR_L;
        private System.Windows.Forms.Button buttonHome;
    }
}