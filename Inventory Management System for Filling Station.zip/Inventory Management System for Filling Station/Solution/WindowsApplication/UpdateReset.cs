﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsApplication
{
    public partial class UpdateReset : Form
    {
        public UpdateReset()
        {
            InitializeComponent();
        }

        public void Back()
        {
            FormLogin ob = new FormLogin();
            ob.Show();
            this.Hide();
        }

        private void buttonBackUR_L_Click(object sender, EventArgs e)
        {
            Back();
        }

        private void buttonPConfirm_Click(object sender, EventArgs e)
        {
            MyDBDataContext mdc = new MyDBDataContext(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\ashar\Desktop\Inventory Management System for Filling Station\Solution\WindowsApplication\db.mdf;Integrated Security=True;Connect Timeout=30");
            var record = from a in mdc.IdPasses
                         select a;

            if (radioButtonUpdate.Checked == true)
            {
                if (textBoxOldpass.Text == record.First().Password)
                {
                    if (textBoxNewPassP.Text == textBoxConfirmPassP.Text)
                    {
                        IdPass u = record.First();
                        u.Password = textBoxConfirmPassP.Text;
                        mdc.SubmitChanges();
                        MessageBox.Show("Password Updated SuccessFully.");

                        Back();

                    }
                    else
                    {
                        MessageBox.Show("Password Doesn't Match!\nEnter Again.");
                        textBoxNewPassP.Text = null;
                        textBoxConfirmPassP.Text = null;
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Password Given!");
                    textBoxOldpass.Text = null;
                    textBoxNewPassP.Text = null;
                    textBoxConfirmPassP.Text = null;
                }
            }

            else if (radioButtonReset.Checked == true)
            {
                if (textBoxProKey.Text == "A00R01N10O11B")                  //Product Key.
                {
                    if (textBoxNewPassR.Text == textBoxConfirmPassR.Text)
                    {
                        IdPass u = record.First();
                        u.Password = textBoxConfirmPassR.Text;
                        mdc.SubmitChanges();
                        MessageBox.Show("Password Reset Successfully.");

                        Back();
                    }
                    else
                    {
                        MessageBox.Show("Password Doesn't Match!\nEnter Again.");
                        textBoxNewPassR.Text = null;
                        textBoxConfirmPassR.Text = null;
                    }
                }

                else
                {
                    MessageBox.Show("Invalid Product Key!");
                    textBoxProKey.Text = null;
                    textBoxNewPassR.Text = null;
                    textBoxConfirmPassR.Text = null;
                }
            }
            else
                MessageBox.Show("Nothing was selected");
        }

        private void UpdateReset_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void radioButtonUpdate_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonUpdate.Checked)
            {
                labelOldPass.Visible = true;
                labelNewPassP.Visible = true;
                labelConfirmPassP.Visible = true;
                textBoxOldpass.Visible = true;
                textBoxNewPassP.Visible = true;
                textBoxConfirmPassP.Visible = true;
                buttonConfirm.Visible = true;

            }
            else
            {
                labelOldPass.Visible = false;
                labelNewPassP.Visible = false;
                labelConfirmPassP.Visible = false;
                textBoxOldpass.Visible = false;
                textBoxNewPassP.Visible = false;
                textBoxConfirmPassP.Visible = false;
                buttonConfirm.Visible = false;
            }
        }

        private void radioButtonReset_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonReset.Checked)
            {
                labelProKey.Visible = true;
                labelNewPassR.Visible = true;
                labelConfirmPassR.Visible = true;
                textBoxProKey.Visible = true;
                textBoxNewPassR.Visible = true;
                textBoxConfirmPassR.Visible = true;
                buttonConfirm.Visible = true;
            }
            else
            {
                labelProKey.Visible = false;
                labelNewPassR.Visible = false;
                labelConfirmPassR.Visible = false;
                textBoxProKey.Visible = false;
                textBoxNewPassR.Visible = false;
                textBoxConfirmPassR.Visible = false;
                buttonConfirm.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormLogin ob = new FormLogin();
            ob.Show();
            this.Hide();
        }
    }
}