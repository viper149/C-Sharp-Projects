﻿namespace WindowsApplication
{
    partial class FormAddInventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxUCost = new System.Windows.Forms.TextBox();
            this.textBoxQuantity = new System.Windows.Forms.TextBox();
            this.textBoxTruck = new System.Windows.Forms.TextBox();
            this.comboBoxPName = new System.Windows.Forms.ComboBox();
            this.labelTCost2 = new System.Windows.Forms.Label();
            this.labelTCost = new System.Windows.Forms.Label();
            this.labelQuantity = new System.Windows.Forms.Label();
            this.labelUCost = new System.Windows.Forms.Label();
            this.labelTruck = new System.Windows.Forms.Label();
            this.labelPName = new System.Windows.Forms.Label();
            this.buttonBack = new System.Windows.Forms.Button();
            this.buttonHome = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBoxUCost
            // 
            this.textBoxUCost.Location = new System.Drawing.Point(258, 216);
            this.textBoxUCost.Multiline = true;
            this.textBoxUCost.Name = "textBoxUCost";
            this.textBoxUCost.Size = new System.Drawing.Size(189, 31);
            this.textBoxUCost.TabIndex = 11;
            // 
            // textBoxQuantity
            // 
            this.textBoxQuantity.Location = new System.Drawing.Point(258, 168);
            this.textBoxQuantity.Multiline = true;
            this.textBoxQuantity.Name = "textBoxQuantity";
            this.textBoxQuantity.Size = new System.Drawing.Size(189, 31);
            this.textBoxQuantity.TabIndex = 12;
            // 
            // textBoxTruck
            // 
            this.textBoxTruck.Location = new System.Drawing.Point(258, 117);
            this.textBoxTruck.Multiline = true;
            this.textBoxTruck.Name = "textBoxTruck";
            this.textBoxTruck.Size = new System.Drawing.Size(189, 31);
            this.textBoxTruck.TabIndex = 13;
            // 
            // comboBoxPName
            // 
            this.comboBoxPName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBoxPName.Font = new System.Drawing.Font("Georgia", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxPName.FormattingEnabled = true;
            this.comboBoxPName.Items.AddRange(new object[] {
            "Diesel",
            "Octane",
            "Petrol",
            "CNG"});
            this.comboBoxPName.Location = new System.Drawing.Point(261, 71);
            this.comboBoxPName.Name = "comboBoxPName";
            this.comboBoxPName.Size = new System.Drawing.Size(121, 26);
            this.comboBoxPName.TabIndex = 10;
            this.comboBoxPName.Text = "Select Product";
            // 
            // labelTCost2
            // 
            this.labelTCost2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.labelTCost2.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTCost2.Location = new System.Drawing.Point(258, 264);
            this.labelTCost2.Name = "labelTCost2";
            this.labelTCost2.Size = new System.Drawing.Size(189, 24);
            this.labelTCost2.TabIndex = 9;
            this.labelTCost2.Text = "Generate";
            this.labelTCost2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.labelTCost2.Click += new System.EventHandler(this.labelTCost2_Click);
            // 
            // labelTCost
            // 
            this.labelTCost.AutoSize = true;
            this.labelTCost.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTCost.Location = new System.Drawing.Point(36, 264);
            this.labelTCost.Name = "labelTCost";
            this.labelTCost.Size = new System.Drawing.Size(110, 21);
            this.labelTCost.TabIndex = 4;
            this.labelTCost.Text = "Total Cost :";
            // 
            // labelQuantity
            // 
            this.labelQuantity.AutoSize = true;
            this.labelQuantity.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelQuantity.Location = new System.Drawing.Point(35, 168);
            this.labelQuantity.Name = "labelQuantity";
            this.labelQuantity.Size = new System.Drawing.Size(86, 21);
            this.labelQuantity.TabIndex = 5;
            this.labelQuantity.Text = "Quantity";
            // 
            // labelUCost
            // 
            this.labelUCost.AutoSize = true;
            this.labelUCost.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUCost.Location = new System.Drawing.Point(35, 216);
            this.labelUCost.Name = "labelUCost";
            this.labelUCost.Size = new System.Drawing.Size(91, 21);
            this.labelUCost.TabIndex = 6;
            this.labelUCost.Text = "Unit Cost";
            // 
            // labelTruck
            // 
            this.labelTruck.AutoSize = true;
            this.labelTruck.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTruck.Location = new System.Drawing.Point(35, 117);
            this.labelTruck.Name = "labelTruck";
            this.labelTruck.Size = new System.Drawing.Size(92, 21);
            this.labelTruck.TabIndex = 7;
            this.labelTruck.Text = "Truck No";
            // 
            // labelPName
            // 
            this.labelPName.AutoSize = true;
            this.labelPName.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPName.Location = new System.Drawing.Point(36, 70);
            this.labelPName.Name = "labelPName";
            this.labelPName.Size = new System.Drawing.Size(132, 21);
            this.labelPName.TabIndex = 8;
            this.labelPName.Text = "Product Name";
            // 
            // buttonBack
            // 
            this.buttonBack.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonBack.BackColor = System.Drawing.Color.Transparent;
            this.buttonBack.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBack.ForeColor = System.Drawing.Color.Black;
            this.buttonBack.Location = new System.Drawing.Point(420, 316);
            this.buttonBack.Margin = new System.Windows.Forms.Padding(1);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(75, 30);
            this.buttonBack.TabIndex = 14;
            this.buttonBack.Text = "Back";
            this.buttonBack.UseVisualStyleBackColor = false;
            this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
            // 
            // buttonHome
            // 
            this.buttonHome.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonHome.BackColor = System.Drawing.Color.Transparent;
            this.buttonHome.Font = new System.Drawing.Font("Palatino Linotype", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonHome.ForeColor = System.Drawing.Color.Black;
            this.buttonHome.Location = new System.Drawing.Point(-2, -4);
            this.buttonHome.Margin = new System.Windows.Forms.Padding(1);
            this.buttonHome.Name = "buttonHome";
            this.buttonHome.Size = new System.Drawing.Size(49, 21);
            this.buttonHome.TabIndex = 17;
            this.buttonHome.Text = "Home";
            this.buttonHome.UseVisualStyleBackColor = false;
            this.buttonHome.Click += new System.EventHandler(this.buttonHome_Click_1);
            // 
            // FormAddInventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(925, 356);
            this.Controls.Add(this.buttonHome);
            this.Controls.Add(this.buttonBack);
            this.Controls.Add(this.textBoxUCost);
            this.Controls.Add(this.textBoxQuantity);
            this.Controls.Add(this.textBoxTruck);
            this.Controls.Add(this.comboBoxPName);
            this.Controls.Add(this.labelTCost2);
            this.Controls.Add(this.labelTCost);
            this.Controls.Add(this.labelQuantity);
            this.Controls.Add(this.labelUCost);
            this.Controls.Add(this.labelTruck);
            this.Controls.Add(this.labelPName);
            this.Name = "FormAddInventory";
            this.Text = "FormAddInventory";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormAddInventory_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxUCost;
        private System.Windows.Forms.TextBox textBoxQuantity;
        private System.Windows.Forms.TextBox textBoxTruck;
        private System.Windows.Forms.ComboBox comboBoxPName;
        private System.Windows.Forms.Label labelTCost2;
        private System.Windows.Forms.Label labelTCost;
        private System.Windows.Forms.Label labelQuantity;
        private System.Windows.Forms.Label labelUCost;
        private System.Windows.Forms.Label labelTruck;
        private System.Windows.Forms.Label labelPName;
        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.Button buttonHome;
    }
}