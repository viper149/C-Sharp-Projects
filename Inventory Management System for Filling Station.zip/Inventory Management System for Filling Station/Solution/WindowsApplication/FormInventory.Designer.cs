﻿namespace WindowsApplication
{
    partial class FormInventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAddInv = new System.Windows.Forms.Button();
            this.buttonStockInv = new System.Windows.Forms.Button();
            this.buttonTrans = new System.Windows.Forms.Button();
            this.buttonBackW_L = new System.Windows.Forms.Button();
            this.buttonHome = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonAddInv
            // 
            this.buttonAddInv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(231)))), ((int)(((byte)(249)))));
            this.buttonAddInv.Location = new System.Drawing.Point(83, 100);
            this.buttonAddInv.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.buttonAddInv.Name = "buttonAddInv";
            this.buttonAddInv.Size = new System.Drawing.Size(195, 56);
            this.buttonAddInv.TabIndex = 0;
            this.buttonAddInv.Text = "Add Inventory";
            this.buttonAddInv.UseVisualStyleBackColor = false;
            this.buttonAddInv.Click += new System.EventHandler(this.buttonAddInv_Click);
            // 
            // buttonStockInv
            // 
            this.buttonStockInv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(231)))), ((int)(((byte)(249)))));
            this.buttonStockInv.Location = new System.Drawing.Point(386, 100);
            this.buttonStockInv.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.buttonStockInv.Name = "buttonStockInv";
            this.buttonStockInv.Size = new System.Drawing.Size(195, 56);
            this.buttonStockInv.TabIndex = 1;
            this.buttonStockInv.Text = "Stock Inventory";
            this.buttonStockInv.UseVisualStyleBackColor = false;
            this.buttonStockInv.Click += new System.EventHandler(this.buttonStockInv_Click);
            // 
            // buttonTrans
            // 
            this.buttonTrans.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(231)))), ((int)(((byte)(249)))));
            this.buttonTrans.Location = new System.Drawing.Point(695, 100);
            this.buttonTrans.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.buttonTrans.Name = "buttonTrans";
            this.buttonTrans.Size = new System.Drawing.Size(195, 56);
            this.buttonTrans.TabIndex = 2;
            this.buttonTrans.Text = "Transaction";
            this.buttonTrans.UseVisualStyleBackColor = false;
            this.buttonTrans.Click += new System.EventHandler(this.buttonTrans_Click);
            // 
            // buttonBackW_L
            // 
            this.buttonBackW_L.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonBackW_L.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(231)))), ((int)(((byte)(249)))));
            this.buttonBackW_L.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBackW_L.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(116)))), ((int)(((byte)(99)))));
            this.buttonBackW_L.Location = new System.Drawing.Point(443, 321);
            this.buttonBackW_L.Margin = new System.Windows.Forms.Padding(1);
            this.buttonBackW_L.Name = "buttonBackW_L";
            this.buttonBackW_L.Size = new System.Drawing.Size(75, 30);
            this.buttonBackW_L.TabIndex = 4;
            this.buttonBackW_L.Text = "Back";
            this.buttonBackW_L.UseVisualStyleBackColor = false;
            this.buttonBackW_L.Click += new System.EventHandler(this.buttonBackW_L_Click);
            // 
            // buttonHome
            // 
            this.buttonHome.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonHome.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(206)))), ((int)(((byte)(201)))));
            this.buttonHome.Font = new System.Drawing.Font("Palatino Linotype", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonHome.ForeColor = System.Drawing.Color.Black;
            this.buttonHome.Location = new System.Drawing.Point(0, -1);
            this.buttonHome.Margin = new System.Windows.Forms.Padding(1);
            this.buttonHome.Name = "buttonHome";
            this.buttonHome.Size = new System.Drawing.Size(49, 21);
            this.buttonHome.TabIndex = 17;
            this.buttonHome.Text = "Home";
            this.buttonHome.UseVisualStyleBackColor = false;
            this.buttonHome.Click += new System.EventHandler(this.button1_Click);
            // 
            // FormInventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsApplication.Properties.Resources.LNG_CNG_08;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(926, 361);
            this.Controls.Add(this.buttonHome);
            this.Controls.Add(this.buttonBackW_L);
            this.Controls.Add(this.buttonTrans);
            this.Controls.Add(this.buttonStockInv);
            this.Controls.Add(this.buttonAddInv);
            this.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(179)))), ((int)(((byte)(116)))), ((int)(((byte)(99)))));
            this.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.Name = "FormInventory";
            this.Text = "Inventory";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormInventory_FormClosing);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonAddInv;
        private System.Windows.Forms.Button buttonStockInv;
        private System.Windows.Forms.Button buttonTrans;
        private System.Windows.Forms.Button buttonBackW_L;
        private System.Windows.Forms.Button buttonHome;
    }
}