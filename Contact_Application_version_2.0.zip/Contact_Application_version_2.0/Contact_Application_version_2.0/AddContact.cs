﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Business_Logic_Layer;
namespace Presentation_Layer
{
    public partial class AddContact : Form
    {
        Person p = new Person();
        Form1 f1;
        public AddContact()
        {
            InitializeComponent();
        }
        public AddContact(Form1 f1)
        {
            InitializeComponent();
            this.f1 = f1;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void AddContact_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (textBox1.Text == string.Empty)
            {
                textBox1.Text = "Name";
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "Name")
            {
                textBox1.Text = string.Empty;
            }
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            if (textBox2.Text == string.Empty)
            {
                textBox2.Text = "Phone Number";
            }
        }

        private void textBox2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "Phone Number")
            {
                textBox1.Text = string.Empty;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            p.AddPerson(textBox1.Text,textBox2.Text);
            MessageBox.Show("Contact Added");
            this.Hide();
            f1.ShowThis();
        }
    }
}
