﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Business_Logic_Layer;
namespace Presentation_Layer
{
    public partial class UpdateContact : Form
    {
        int i;
        Person p = new Person();
        Form1 f1;
        public UpdateContact()
        {
            InitializeComponent();
        }
        public UpdateContact(Form1 f1)
        {
            InitializeComponent();
            this.f1 = f1;
        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void AddContact_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {

        }

        

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "Enter ID and Press Tab")
            {
                textBox1.Text = string.Empty;
            }
            
        }

        private void UpdateContact_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = p.GetPersonList();
            textBox2.Visible = textBox3.Visible = true;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
             i =(int)dataGridView1.Rows[(dataGridView1.SelectedCells[0].RowIndex)].Cells[0].Value;
            textBox2.Text = dataGridView1.Rows[(dataGridView1.SelectedCells[0].RowIndex)].Cells[1].Value.ToString();
            textBox3.Text = dataGridView1.Rows[(dataGridView1.SelectedCells[0].RowIndex)].Cells[2].Value.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            p.UpdatePerson(i,textBox2.Text,textBox3.Text);
            MessageBox.Show("Contact Updated");
            textBox2.Text = textBox3.Text = "";
            dataGridView1.DataSource = p.GetPersonList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            f1.ShowThis();
        }

        

        
    }
}
