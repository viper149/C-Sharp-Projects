﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Business_Logic_Layer;

namespace Presentation_Layer
{
    public partial class Form1 : Form
    {
        Person p = new Person();
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            AddContact ac = new AddContact(this);
            this.Hide();
            ac.Show();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DeleteContact dc = new DeleteContact(this);
            this.Hide();
            dc.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            UpdateContact uc = new UpdateContact(this);
            this.Hide();
            uc.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = p.GetPersonList().ToList();
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = p.GetSearchPerson(textBox1.Text);
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "Search Name";
                dataGridView1.DataSource = p.GetPersonList().ToList();
                
            }
        }

        private void textBox1_Click_1(object sender, EventArgs e)
        {
            
            
        }

         public void ShowThis()
        {
            this.Show();
            dataGridView1.DataSource = p.GetPersonList().ToList();
        }
    }
}
