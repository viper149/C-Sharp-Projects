﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data_Access_Layer;
namespace Business_Logic_Layer
{
    public class Person
    {
        int id;
        string name;
        string phone;
        DataAccess da = new DataAccess();
        public int ID
        {
            set { this.id = value; }
            get { return this.id; }
 
        }
        public string Name
        {
            set { this.name = value; }
            get { return this.name; }

        }
        public string Phone
        {
            set { this.phone = value; }
            get { return this.phone; }

        }
        public List<object> GetPersonList()
        {
            List<object> p = da.GetList();

            return p.ToList();
        }

        public object GetSearchPerson(string n)
        {
            object p = da.GetPerson(n);

            return p;
        }

        public void AddPerson(string n, string p)
        {
            da.AddPerson(n,p);
        }
        public void DeletePerson(int i)
        {
            da.DeletePerson(i);
        }

        public object GetPersonById(int n)
        {
            object p = da.UpdateSearchPerson(n);

            return p;
        }

        public void UpdatePerson(int i,string n, string p)
        {
            da.UpdatePerson(i,n, p);
        }
    }
}
