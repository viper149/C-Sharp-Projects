﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access_Layer
{
    public class DataAccess
    {
        public static ContactDataContext cdc = new ContactDataContext(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=c:\users\victorstanyrozario\documents\visual studio 2012\Projects\Contact_Application_version_2.0\Data Access Layer\PhoneBook.mdf;Integrated Security=True;Connect Timeout=30");

        public List<object> GetList()
        {
            var x = from a in cdc.Names
                    join b in cdc.Phones
                    on a.Id equals b.NameId
                    select new { a.Id,Name=a.Person_Name, b.Number };

            List<object> o = new List<object>() ;
            o.AddRange(x.ToList());
            return o;
        }

        public object GetPerson(string n)
        {
            var x = from a in cdc.Names
                    join b in cdc.Phones
                    on a.Id equals b.NameId
                    where a.Person_Name==n
                    select new { a.Id,a.Person_Name, b.Number };

            object o = x.ToList();
            return o;
        }

        

        public void AddPerson(string n, string p)
        {
            Name name = new Name();
            name.Person_Name = n;

            cdc.Names.InsertOnSubmit(name);
            cdc.SubmitChanges();
            
            


            var x = from a in cdc.Names
                    orderby a.Id descending
                    select a.Id;
            Phone phn = new Phone();
            phn.Number = p;
            phn.NameId = x.FirstOrDefault();

            
            cdc.Phones.InsertOnSubmit(phn);
            cdc.SubmitChanges();

                  

        }

        public void DeletePerson(int i)
        {
            
            var p =from a in cdc.Phones
                   where a.NameId==i
                   select a;
            foreach (Phone z in p.ToList())
            {
                cdc.Phones.DeleteOnSubmit(z);
            }

            Name n = cdc.Names.Single(x => x.Id == i);
            cdc.Names.DeleteOnSubmit(n);
            cdc.SubmitChanges();



        }

        public object UpdateSearchPerson(int i)
        {

            var x = from a in cdc.Names
                    join b in cdc.Phones
                    on a.Id equals b.NameId
                    where a.Id == i
                    select new { a.Id, Name=a.Person_Name, b.Number };

            object o = x.ToList();
            return o;
         
        }

        public void UpdatePerson(int i,string n,string p)
        {

            

            Name name = cdc.Names.Single(X=>X.Id==i);
            name.Person_Name = n;
            var x = from a in cdc.Phones
                    where a.NameId == i
                    select a;
            foreach (Phone phn in cdc.Phones.Where(X => X.NameId == i))
            {
                Phone ph = x.First();
                ph.Number = p;
                cdc.SubmitChanges();
            }

        }

    }
}
